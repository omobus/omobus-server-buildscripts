#ifndef IMAP_URLAUTH_LOGIN_SETTINGS_H
#define IMAP_URLAUTH_LOGIN_SETTINGS_H

extern const struct setting_parser_info *imap_urlauth_login_setting_roots[];

#endif
