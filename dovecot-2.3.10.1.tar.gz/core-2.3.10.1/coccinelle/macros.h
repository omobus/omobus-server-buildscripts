#define T_BEGIN
#define T_END
#define ARRAY_DEFINE_TYPE(x, y)
#define ARRAY_TYPE(x)
#define ARRAY(x)
#define ATTR_NULL(x)
#define ATTR_FORMAT(x, y)
#define ATTR_PURE
#define TRUE 1
#define FALSE 0
#define MODULE_CONTEXT_DEFINE(x, y)
#define MODULE_CONTEXT_REQUIRE(x, y)
#define MODULE_CONTEXT(x, y)
#define DICT_PATH_SHARED
#define HASH_TABLE(x, y)
