# Security Policy

## Supported Versions

For community, we support only the latest released version. Please see https://www.dovecot.org/download for latest version.

## Reporting a Vulnerability or security issue

To report vulnerabilities and other security issues, please use https://hackerone.com/open-xchange.
Please read the program scope carefully.
