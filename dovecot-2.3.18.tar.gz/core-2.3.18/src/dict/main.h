#ifndef MAIN_H
#define MAIN_H

void dict_proctitle_update_later(void);

#endif
