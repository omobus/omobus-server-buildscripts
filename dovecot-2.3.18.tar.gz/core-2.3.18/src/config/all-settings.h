#ifndef ALL_SETTINGS_H
#define ALL_SETTINGS_H

extern const struct setting_parser_info *const *all_roots;
extern const struct setting_parser_info *all_default_roots[];
extern ARRAY_TYPE(service_settings) *default_services;

#endif
